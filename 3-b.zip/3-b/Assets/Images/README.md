Spaceship illustration taken from here:
https://www.kenney.nl/assets/space-kit
License: CC0 1.0 Universal.




