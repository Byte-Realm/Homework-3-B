using UnityEngine;
using UnityEngine.InputSystem;

public class WeaponParent : MonoBehaviour
{
    [SerializeField] private InputAction attackAction; // Input action for attack
    [SerializeField] private GameObject sword; // Reference to the Sword GameObject
    private Animator swordAnimator; // Animator on the Sword

    private void OnEnable()
    {
        swordAnimator = sword.GetComponent<Animator>(); // Gets the animator component tied to the given GameObject
        attackAction.Enable();
    }

    private void OnDisable()
    {
        attackAction.Disable();
    }

    private void Update()
    {
        if (attackAction.triggered)
        {
            swordAnimator.SetTrigger("Attack");
        }
    }

}
