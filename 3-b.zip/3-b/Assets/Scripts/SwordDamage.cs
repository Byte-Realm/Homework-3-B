using UnityEngine;

public class SwordDamage : MonoBehaviour
{
    [SerializeField] private int damage = 10;
    [SerializeField] private string opponentTag = "Player";
    [SerializeField] private float knockbackForce = 5f;

    private bool isAttacking = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isAttacking && collision.CompareTag(opponentTag))
        {
            PlayerHealth opponentHealth = collision.GetComponent<PlayerHealth>();
            if (opponentHealth != null)
            {
                Vector2 knockbackDirection = (collision.transform.position - transform.position).normalized;
                opponentHealth.TakeDamage(damage, knockbackDirection, knockbackForce);
            }
        }
    }

    // These methods must be public and exactly named as intended
    public void EnableAttack()
    {
        isAttacking = true;
    }

    public void DisableAttack()
    {
        isAttacking = false;
    }
}
