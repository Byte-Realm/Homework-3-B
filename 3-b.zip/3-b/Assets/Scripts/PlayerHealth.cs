using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private int maxHealth = 100; // Maximum health of the player
    private int currentHealth;
    public int CurrentHealth => currentHealth; // => makes CurrentHealth read-only
    private Rigidbody2D rigidBody; // Rigid Body reference for the knock back on hit
    [SerializeField] private Slider healthBar; // Slider rpresenting the hp of the play it's attached to

    private void Start()
    {
        currentHealth = maxHealth; 
        rigidBody = GetComponent<Rigidbody2D>();                              
        if (healthBar != null) // Initialize the health bar
        {
            healthBar.maxValue = maxHealth;
            healthBar.value = currentHealth;
        }
    }

    public void TakeDamage(int damage, Vector2 knockbackDirection, float knockbackForce)
    {
        currentHealth -= damage;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        knockBack(knockbackDirection, knockbackForce);
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>(); // saves the sprite color of the player
        Color originalColor = spriteRenderer.color;
        StartCoroutine(FlashWhite());
        if (spriteRenderer.color != originalColor)
        {
            spriteRenderer.color = originalColor;
        }
        if (healthBar != null)
        {
            healthBar.value = currentHealth;
        }
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void knockBack(Vector2 direction, float force)
    {
        if (rigidBody != null)
        {
            rigidBody.AddForce(direction * force, ForceMode2D.Impulse);
        }
    }

    private void Die()
    {
        Debug.Log($"{gameObject.name} has been defeated!");
        gameObject.SetActive(false);
    }

    private IEnumerator FlashWhite()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
        {
            Color originalColor = spriteRenderer.color;

            // Flash white
            spriteRenderer.color = Color.white;
            yield return new WaitForSeconds(0.1f);

            // Revert to original color
            spriteRenderer.color = originalColor;
        }
    }
}
