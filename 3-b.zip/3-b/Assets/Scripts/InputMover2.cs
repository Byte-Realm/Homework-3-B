using UnityEngine;
using UnityEngine.InputSystem;

public class InputMover2 : MonoBehaviour
{
    [Tooltip("Speed of movement, in meters per second")]
    [SerializeField] float speed = 10f;
    private float offSet = 0.05f;
    [SerializeField]
    InputAction move = new InputAction(type: InputActionType.Value, expectedControlType: nameof(Vector2));

    private Vector2 moveDirection;

    [SerializeField] private Camera mainCamera;
    private float worldWidth;
    private float worldHeight;

    void OnEnable()
    {
        move.Enable();
    }

    void OnDisable()
    {
        move.Disable();
    }

    private void Start()
    {
        Vector3 screenBounds = mainCamera.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, 0));
        worldWidth = screenBounds.x;
        worldHeight = screenBounds.y;
    }

    void Update()
    {
        // Read input
        moveDirection = move.ReadValue<Vector2>();

        // Move the player
        Vector3 movementVector = new Vector3(moveDirection.x, moveDirection.y, 0) * speed * Time.deltaTime;
        transform.position += movementVector;
        // Flip player based on movement direction
        FlipPlayer(moveDirection.x);

        if (transform.position.x > worldWidth)
        {
            transform.position = new Vector3(-worldWidth + offSet, transform.position.y, transform.position.z);
        }
        else if (transform.position.x < -worldWidth)
        {
            transform.position = new Vector3(worldWidth - offSet, transform.position.y, transform.position.z);
        }

    }

    private void FlipPlayer(float horizontalInput)
    {
        if (horizontalInput > 0)
        {
            // Face right
            transform.localScale = new Vector3(-0.5f, 0.5f, 1);
        }
        else if (horizontalInput < 0)
        {
            // Face left
            transform.localScale = new Vector3(0.5f, 0.5f, 1);
        }
    }
}
